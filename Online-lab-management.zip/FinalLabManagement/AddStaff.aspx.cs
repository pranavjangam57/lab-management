﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    General G = new General();
    DataSet ds;
    int StaffId;
    protected void Page_Load(object sender, EventArgs e)
    {
        NewStaff();
       }
   
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string Branch, Shift;
        LblMsg.Visible = false;
        if (Page.IsValid)
        {
            string check = "select * from STAFF_DB where Email='"+TxtEmailID.Text+"' and StaffName='"+txtStaffName.Text+"'";
            ds = G.Getdata(check);
            if (ds.Tables[0].Rows.Count == 0)
            {
               
                Branch = DdlAddStaf.SelectedItem.Value.ToString();
                Shift = DdlShift.SelectedItem.Value.ToString();
                
                string qr = "insert into STAFF_DB values ('"+StaffId+"','"+txtStaffName.Text+"','"+txtStaffAddress.Text+"','"+txtStaffContact.Text+"','"+TxtEmailID.Text+"','"+Branch+"','"+Shift+"','"+txtConfirmpassword.Text+"','Staff')";
                G.Changedata(qr);
                LblMsg.Visible = true; LblMsg.Text = "Please Note your Staff ID '"+StaffId+"' for futher use.";
                ClearAll();
            }
            else { LblMsg.Visible = true; LblMsg.Text = "Member Allready Exist !"; }
        }
    }
    public void ClearAll() { txtStaffName.Text = txtStaffAddress.Text = txtStaffContact.Text = TxtEmailID.Text = ""; DdlAddStaf.SelectedIndex = 0; DdlShift.SelectedIndex = 0; }
    protected void btnAnother_Click(object sender, EventArgs e)
    {
        NewStaff();
    }
    public void NewStaff()
    {
        ds = G.Getdata("select max(StaffId+1) from STAFF_DB");
        if (ds.Tables[0].Rows.Count > 0) { StaffId = Int32.Parse(ds.Tables[0].Rows[0][0].ToString()); txtStaffId.Text = Convert.ToString(StaffId); }
    
    }
}
