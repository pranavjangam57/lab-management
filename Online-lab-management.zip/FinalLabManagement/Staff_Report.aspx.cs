﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Staff_Report : System.Web.UI.Page
{
    General G = new General();
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        rbtMonthly.Visible = ReportDate.Visible=false;
        
    }
    string qr;
    protected void btnStaffreport_Click(object sender, EventArgs e)
    {
        if(CheckStaff()){
        DateTime d = new DateTime();
        d = Convert.ToDateTime(ReportDate.SelectedDate.Date);
       d= Convert.ToDateTime( d.ToString("MM-dd-yyyy"));
        if (rbtMonthly.SelectedItem.Value == "Monthly")
        {

            qr = "select Year('" + d + "') as 'YEAR',MONTH('" + d + "') as 'MONTH', li.*,lo.Out_Time from LoginDB as li Full outer Join LogOutDB as lo on (li.ID=lo.ID and li.ForDate=Lo.fordate and li.Subject=lo.Subject) where li.ID='" + int.Parse(txtstaffreportID.Text) + "' and Year('" + d + "')=Year(In_Time) and MONTH('" + d + "')=MONTH(In_Time) order by li.ID,Month(li.in_Time),Year(li.In_Time)";

        }
        else if (rbtMonthly.SelectedItem.Value == "Yearly") { qr = "select TOP(12) Year('" + d + "') as 'ATTENDANCE YEAR',MONTH('" + d + "') as 'ATTENDANCE MONTH', count(*) as 'TOTAL PRESENT DAYS' from LoginDB where ID='" + int.Parse(txtstaffreportID.Text) + "' and MONTH('" + d + "')=MONTH(In_Time) and Year('" + d + "')=Year(In_Time) Group By Year(In_Time),Month(In_Time) Order By Month(In_Time)"; }

       ds=G.Getdata(qr);
        if(ds.Tables[0].Rows.Count>0)
        {
            GridShowReport.DataSource = ds; GridShowReport.DataBind();
        }}

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ReportDate.Visible = true;
    }
    protected void ReportDate_SelectionChanged(object sender, EventArgs e)
    {
        //ReportDate.Visible = false;
        LblDate.Text = ReportDate.SelectedDate.ToString("Y");
    }
    public bool CheckStaff()
    {
        string qr1;
        qr1 = "select * From STAFF_DB st where st.StaffId='" + Convert.ToUInt32(txtstaffreportID.Text) + "' and Branch='" + DdlBranch.SelectedItem.Value + "' and Email='" + txtEmail.Text + "'";
    ds = G.Getdata(qr1);
    if (ds.Tables[0].Rows.Count > 0)
    { return true; }
    else { return false; }
    }
    protected void GridShowReport_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
