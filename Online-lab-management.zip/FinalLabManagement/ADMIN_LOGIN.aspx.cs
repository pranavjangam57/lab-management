﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ADMIN_LOGIN : System.Web.UI.Page
{
    General G= new General();
    SqlConnection Conn;
    protected void Page_Load(object sender, EventArgs e)
    {
         Conn = G.con;
    }
    protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
    {
        string username = Login1.UserName;
            string pwd = Login1.Password;

            string strConn;
            
            
            Conn.Open();

            string sqlUserName;
            sqlUserName = "SELECT Username,Password , User_id FROM UserInfo ";
            sqlUserName += " WHERE (Username = @Username";
            sqlUserName += " AND Password = @Password)";


            SqlCommand com = new SqlCommand(sqlUserName, Conn);
            com.Parameters.AddWithValue("@Username", username);
            com.Parameters.AddWithValue("@Password", pwd);



            string CurrentName;
            CurrentName = (string)com.ExecuteScalar();

            if (CurrentName != null)
            {
                Session["UserAuthentication"] = username;
                //Session["User_id"] = username;
                Session.Timeout = 5;
                Response.Redirect("AddStaff.aspx");

            }
            else
            {
                Session["UserAuthentication"] = "";
            }
        }

        
    }
   
