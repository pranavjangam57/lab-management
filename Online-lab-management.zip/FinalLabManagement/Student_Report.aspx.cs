﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Student_Report : System.Web.UI.Page
{
    General G = new General(); DataSet ds;
    string qr;
    protected void Page_Load(object sender, EventArgs e)
    {
        ReportDate.Visible = false;  
    }
    protected void ReportDate_SelectionChanged(object sender, EventArgs e)
    {
        ReportDate.Visible = false;
        LblDate.Text = ReportDate.SelectedDate.ToString("Y");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ReportDate.Visible = true;
    }
    protected void btnStudSubmitreport_Click(object sender, EventArgs e)
    {
        DateTime d = new DateTime();
        d = Convert.ToDateTime(ReportDate.SelectedDate.Date);
        d = Convert.ToDateTime(d.ToString("MM-dd-yyyy"));
        if (rbtStudReport.SelectedItem.Value == "Monthly")
        {

            qr = "select Year('" + d + "') as 'YEAR',MONTH('" + d + "') as 'MONTH', li.*,lo.Out_Time from LoginDB as li Full outer Join LogOutDB as lo on (li.ID=lo.ID and li.ForDate=Lo.fordate and li.Subject=lo.Subject) where li.ID='" + int.Parse(txtStudEnrollreport.Text) + "' and Year('" + d + "')=Year(In_Time) and MONTH('" + d + "')=MONTH(In_Time) order by li.ID,Month(li.in_Time),Year(li.In_Time)";

        }
        else if (rbtStudReport.SelectedItem.Value == "Yearly") { qr = "select TOP(12) Year('" + d + "') as 'ATTENDANCE YEAR',MONTH('" + d + "') as 'ATTENDANCE MONTH', count(*) as 'TOTAL PRESENT DAYS' from LoginDB where ID='" + int.Parse(txtStudEnrollreport.Text) + "' and MONTH('" + d + "')=MONTH(In_Time) and Year('" + d + "')=Year(In_Time) Group By Year(In_Time),Month(In_Time) Order By Month(In_Time)"; }

        ds = G.Getdata(qr);
        if (ds.Tables[0].Rows.Count > 0)
        {
            GridShowStudentReport.DataSource = ds; GridShowStudentReport.DataBind();
        }
    }
}
