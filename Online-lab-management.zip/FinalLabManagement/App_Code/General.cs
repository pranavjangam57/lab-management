﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


/// <summary>
/// Summary description for General
/// </summary>
public class General
{
	public General()
	{
		//
		// TODO: Add constructor logic here
		//
	}
   public SqlConnection con = new SqlConnection(@"Data Source=abc-pc;Initial Catalog=LabManagement;User ID=sa;Password=prakashgeeta");
    
   
    public DataSet Getdata(string strs)
    {
      
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(strs, con);
            da.Fill(ds);
            return ds;
       
    }

    public int Changedata(string strs)
    {
        SqlCommand cmd = new SqlCommand(strs, con);
        con.Open();
        int i = cmd.ExecuteNonQuery();
        con.Close();

        if (i > 0)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
}
