﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default3 : System.Web.UI.Page
{
    General G = new General();
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        LblMsg.Visible = false;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {
            string Branch, Shift, Year;
            LblMsg.Visible = false;
            if (Page.IsValid)
            {
                string check = "select * from StudentDB where std_EnrollNo='" + txtEnrollno.Text + "'";
                ds = G.Getdata(check);
                if (ds.Tables[0].Rows.Count == 0)
                {
                    Branch = DdlBranch.SelectedItem.Value.ToString();
                    Shift = ddlShift.SelectedItem.Value.ToString();
                    Year = ddlyear.SelectedItem.Value.ToString();
                    string s="Student";
                    string qr = "insert into StudentDB values ('" + txtEnrollno.Text + "','" + txtStudname.Text + "','" + txtAddress.Text + "','" + txtContact.Text + "','" + Year + "','" + Branch + "','" + Shift + "','" + txtConfirmpass.Text + "','"+s+"')";
                    G.Changedata(qr);
                    LblMsg.Visible = true;
                    LblMsg.Text = "Student Added Successfully";
                }
                else { LblMsg.Visible = true; LblMsg.Text = "EnrollMent Number Allready Exist !"; }
            }

        }
    }
    protected void ddlyear_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
