﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class HOME : System.Web.UI.Page
{
    General G = new General();
    DataSet ds;
    protected void Page_Load(object sender, EventArgs e)
    {
        //LblMsg.Visible = false;
        showPnl();
       
    }
    
    protected void rbtLogin_SelectedIndexChanged(object sender, EventArgs e)
    {
        showPnl();
       
    }

    string qr, qr1, Sub; int ID = 0,PC;

    protected void btnStaffCheckIN_Click(object sender, EventArgs e)
    {
        if (Page.IsValid)
        {

            if (rbtLogin.SelectedIndex == 0)
            { ID = Convert.ToInt32(txtEnrollNum.Text); Sub = DdlStudSubject.SelectedItem.Value.ToString();}
            else { ID = Convert.ToInt32(txtStaffId.Text); Sub = DdlStaffSubject.SelectedItem.Value.ToString();}
            qr = "select * from LoginDB  where ID='" + Convert.ToInt32(ID) + "' and ForDate='" + DateTime.Now.ToString() + "' and Subject='" + Sub + "' and Pc_no='" + PC + "'";
            ds = G.Getdata(qr);
            if (ds.Tables[0].Rows.Count < 1)
            {
                ds.Clear();
                if (rbtLogin.SelectedIndex == 0)
                { qr1 = "select * From StudentDB s where s.std_EnrollNo='" + Convert.ToUInt32(txtEnrollNum.Text) + "' and Branch='" + DdlStudBranch.SelectedItem.Value.ToString() + "' and Password='" + txtStudentPass.Text + "' "; }
                else { qr1 = "select * From STAFF_DB st where st.StaffId='" + Convert.ToUInt32(txtStaffId.Text) + "' and Branch='" + DdlStaffBranch.SelectedItem.Value.ToString() + "' and StaffPassword='" + txtStaffPass.Text + "'"; }
                ds = G.Getdata(qr1);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string AttType = rbtLogin.SelectedItem.Value.ToString();
                    string qr2 = "insert into LoginDB values ('"+txtEnrollNum.Text+"','"+DdlStudSubject.SelectedItem.Value+"','"+DateTime.Now.ToShortDateString()+"','"+DateTime.Now.ToString("d")+"', '" +txtPCNo.Text+ "');";
                    G.Changedata(qr2);
                    LblMsg.Visible = true; LblMsg.Text = "Logged In Successfully !";

                }
                else { LblMsg.Visible = true; LblMsg.Text = "User of this ID Not Exist ! or Enter Correct Password ."; }

            }
            else { LblMsg.Visible = true; LblMsg.Text = "Allready Logged in. For more details Please Contact concern person"; }
        }
    }
     
    protected void btnStaffChkOut_Click(object sender, EventArgs e)
    {if(Page.IsValid){
        if (rbtLogin.SelectedIndex == 0)
    { ID = Convert.ToInt32(txtEnrollNum.Text); Sub = DdlStudSubject.SelectedItem.Value.ToString(); }
    else { ID = Convert.ToInt32(txtStaffId.Text); Sub = DdlStaffSubject.SelectedItem.Value.ToString(); }
    qr = "select * from LoginDB  where ID='" + Convert.ToInt32(ID) + "' and ForDate='" + DateTime.Now.ToString() + "' and Subject='"+Sub+ "' and Pc_no='" +PC+"'";
        ds = G.Getdata(qr);
        if (ds.Tables[0].Rows.Count < 1)
        { ds.Clear();


        string logout = "insert into LogOutDB values ('" + ID + "','"+Sub+"','" + DateTime.Now.ToString() + "','" + DateTime.Now.ToString() + "','" +PC+ "')";
        G.Changedata(logout);
        LblMsg.Visible = true; LblMsg.Text = "Logged out Successfully !";
        }
        else { LblMsg.Visible = true; LblMsg.Text = "Wrong Data Provided.Provide correct Data and try OR Contact Concern Person For help."; }
    }}
    public void showPnl() { switch (rbtLogin.SelectedIndex) { case 0: PnlStudent.Visible = true; PnlStaff.Visible = false; break; case 1: PnlStudent.Visible = false; PnlStaff.Visible = true; break; default: PnlStudent.Visible = true; PnlStaff.Visible = false; break; } }
    
}
