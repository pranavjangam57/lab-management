﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class Settings : System.Web.UI.Page
{
    General g = new General();
    Button btn; 
    protected void Page_Load(object sender, EventArgs e)
    {
        
            showPnl();
            LblMsg.Text = "";
        
       
    }
    
    protected void rbtSetting_SelectedIndexChanged(object sender, EventArgs e)
    {
        showPnl();
       
    }
    string UpdateQr;
   
    protected void btnStaffSubmit_Click(object sender, EventArgs e)
    {
        btn = (Button)sender;
        ExecuteQry();
    }
    public void showPnl() { switch (rbtSetting.SelectedIndex) { case 0: PnlStudentUpdate.Visible = true; PnlStaffUpdate.Visible = false; break; case 1: PnlStudentUpdate.Visible = false; PnlStaffUpdate.Visible = true; break; default: PnlStudentUpdate.Visible = true; PnlStaffUpdate.Visible = false; break; } }
    protected void btnStudSubmit_Click(object sender, EventArgs e)
    {
        btn = (Button)sender;
        ExecuteQry();
    }
    public void ExecuteQry()
    {
        if (Page.IsValid)
        {
            LblMsg.Text = "";

            if (btn.ID == "btnStaffSubmit") { UpdateQr = "update STAFF_DB set StaffPassword ='" + txt_staff_cpass.Text + "' where (StaffId='" + txt_staff_id.Text + "' and Branch='" + DdlStaffBranch.SelectedItem.Value + "' and Email='" + TxtStaffEmail.Text + "' and StaffPassword ='" + txt_staff_opass.Text + "' );"; } else if (btn.ID == "btnStudSubmit") { UpdateQr = "update StudentDB set Password='" + txt_stud_cpass + "' where ( std_EnrollNo='" + txt_enrollment.Text + "' and Branch='" + DdlStudBranch.SelectedItem.Value + "' and Password='" + txt_stud_opass.Text + "' );"; }
            if ((UpdateQr != "") || (UpdateQr != null)) { int i = g.Changedata(UpdateQr); if (i > 0) { LblMsg.Text = "Password Updated Successfully !"; } else { LblMsg.Text = "No password updated . Information Provided was not correct. \n Please try again with correct input !"; } }
        }
    }
}
